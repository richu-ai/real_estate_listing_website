import os

from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Use a stable secret in production. Set SECRET_KEY in Vercel Environment Variables.
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")

# Use DATABASE_URL when provided (recommended for production). Otherwise keep
# SQLite for local development. Vercel's filesystem is ephemeral, so the
# /tmp fallback is only for a demo deployment and does not provide persistent data.
database_url = os.environ.get("DATABASE_URL")
if database_url:
    if database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql+psycopg://", 1)
    elif database_url.startswith("postgresql://"):
        database_url = database_url.replace("postgresql://", "postgresql+psycopg://", 1)
else:
    sqlite_path = "/tmp/site.db" if os.environ.get("VERCEL") else os.path.join(app.instance_path, "site.db")
    os.makedirs(os.path.dirname(sqlite_path), exist_ok=True)
    database_url = f"sqlite:///{sqlite_path}"

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

# Import routes/models after db is created to avoid circular imports.
from . import routes  # noqa: E402,F401
from .models_extended import (  # noqa: E402,F401
    Agent,
    Career,
    Consultation,
    Contact,
    Property,
    Valuation,
)


def create_database():
    with app.app_context():
        db.create_all()


create_database()
