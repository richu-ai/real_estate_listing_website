"""Application entry point for local development and Vercel."""
from app import app


if __name__ == "__main__":
    app.run(debug=True)
